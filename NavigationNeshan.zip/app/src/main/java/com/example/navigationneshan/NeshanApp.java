package com.example.navigationneshan;

import android.app.Application;


import javax.inject.Inject;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public final class NeshanApp extends Application {

}
